let navBar = document.querySelector('.nav_bar');
let offer = document.querySelector('.offer');


window.addEventListener('scroll',()=>{
    let navBarPos = navBar.getBoundingClientRect();
    let scrollPos = window.scrollY;

    if(navBarPos.top<=0)
    {
        navBar.style.position = "fixed";
        navBar.style.top = "0";
        offer.style.marginBottom = '50px';
    }
    else
    {
        navBar.style.position = "relative";
    }
});