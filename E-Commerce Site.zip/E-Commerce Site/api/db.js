const mysql = require('mysql');

const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '12345678',
    port: '3306',
    database: 'herbalproducts',
    connectionLimit: '10',
});
db.getConnection((err,connection)=>{
    if(err)
    throw err;
    console.log("connected ");
})
module.exports.db = db;